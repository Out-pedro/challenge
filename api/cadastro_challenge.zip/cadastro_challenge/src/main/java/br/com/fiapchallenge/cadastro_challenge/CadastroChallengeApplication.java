package br.com.fiapchallenge.cadastro_challenge;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CadastroChallengeApplication {

    public static void main(String[] args) {
        SpringApplication.run(CadastroChallengeApplication.class, args);
    }

}
