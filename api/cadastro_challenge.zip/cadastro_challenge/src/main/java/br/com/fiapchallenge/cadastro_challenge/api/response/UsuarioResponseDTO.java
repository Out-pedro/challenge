package br.com.fiapchallenge.cadastro_challenge.api.response;

public record UsuarioResponseDTO(String id,

                                 String nome,

                                 String email,

                                 String senha,

                                 String login,

                                 String telefone,

                                 String endereco

                                 ) {


}
