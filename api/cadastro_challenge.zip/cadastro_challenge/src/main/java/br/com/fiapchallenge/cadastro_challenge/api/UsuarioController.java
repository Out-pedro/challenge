package br.com.fiapchallenge.cadastro_challenge.api;

import br.com.fiapchallenge.cadastro_challenge.api.request.LoginRequestDTO;
import br.com.fiapchallenge.cadastro_challenge.api.request.UsuarioRequestDTO;
import br.com.fiapchallenge.cadastro_challenge.api.response.UsuarioResponseDTO;
import br.com.fiapchallenge.cadastro_challenge.business.UsuarioService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/user")
@RequiredArgsConstructor
public class UsuarioController {

    private final UsuarioService usuarioService;

    @PostMapping
    public ResponseEntity<UsuarioResponseDTO> gravaDadosUsuario(@RequestBody UsuarioRequestDTO usuarioRequestDTO) {
        UsuarioResponseDTO response = usuarioService.gravarUsuarios(usuarioRequestDTO); // chama o método
        return ResponseEntity.ok(response);
    }

    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestBody LoginRequestDTO loginRequest) {
        boolean ok = usuarioService.verificaLogin(loginRequest.getLogin(), loginRequest.getSenha());
        if (ok) {
            return ResponseEntity.ok("Login realizado com sucesso!");
        } else {
            return ResponseEntity.status(401).body("Login ou senha incorretos");
        }
    }


}
