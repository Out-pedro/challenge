package br.com.fiapchallenge.cadastro_challenge;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CadastroChallengeApplicationTests {

    @Test
    void contextLoads() {
    }

}
